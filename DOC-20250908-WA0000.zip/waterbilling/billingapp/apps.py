from django.apps import AppConfig


class BillingappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'billingapp'

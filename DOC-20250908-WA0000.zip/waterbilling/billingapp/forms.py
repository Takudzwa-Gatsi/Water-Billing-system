from . models import *
from django import forms
from django.forms import ModelForm
from django.contrib.auth.forms import UserCreationForm
from django.forms import HiddenInput,IntegerField
class UserForm(UserCreationForm):
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["password1"].widget.attrs.update({"class": "form-control",'placeholder': 'Password','required': 'required'})
        self.fields["password2"].widget.attrs.update({"class": "form-control",'placeholder': 'Confirm Password','required': 'required'})
    class Meta:
        model = User
        fields = ['firstname','lastname' ,'username','dob','phone','email','address','province','location','meter_number','password1', 'password2']

        widgets = {
            'firstname' : forms.TextInput(attrs = {'class':'form-control','placeholder': 'firstname'}),
            'lastname' : forms.TextInput(attrs = {'class':'form-control','placeholder': 'lastname'}),
            'username' : forms.TextInput(attrs = {'id':'usernamefield','class':'form-control','placeholder':'username'}),
            'phone' : forms.TextInput(attrs = {'class':'form-control','placeholder':'phone'}),
            'email' : forms.EmailInput(attrs = {'id':'emailfield','class':'form-control','placeholder':'email'}),
            'address' : forms.TextInput(attrs = {'class':'form-control','placeholder':'address'}), 
            'dob' : forms.DateTimeInput(attrs = {'class':'form-control','placeholder':'date of birth'}), 
            'meter_number' : forms.TextInput(attrs = {'class':'form-control','placeholder':'meter_number'}),
            'province' : forms.TextInput(attrs = {'class':'form-control','placeholder':'province'}),
            'location' : forms.TextInput(attrs = {'class':'form-control','placeholder':'location'}),
           

           
               
        }

class CompForm(UserCreationForm):
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["password1"].widget.attrs.update({"class": "form-control",'placeholder': 'Password','required': 'required'})
        self.fields["password2"].widget.attrs.update({"class": "form-control",'placeholder': 'Confirm Password','required': 'required'})
    class Meta:
        model = User
        fields = ['firstname','lastname' ,'username','dob','phone','email','address','province','location','meter_number','companyfield','password1','password2']
        
        widgets = {
            'firstname' : forms.TextInput(attrs = {'class':'form-control','placeholder': 'Comp name'}),
            'lastname' : forms.TextInput(attrs = {'class':'form-control','placeholder': 'Other name'}),
            'username' : forms.TextInput(attrs = {'id':'usernamefield','class':'form-control','placeholder':'username'}),
            'phone' : forms.TextInput(attrs = {'class':'form-control','placeholder':'phone'}),
            'email' : forms.EmailInput(attrs = {'id':'emailfield','class':'form-control','placeholder':'email'}),
            'address' : forms.TextInput(attrs = {'class':'form-control','placeholder':'address'}), 
            'dob' : forms.DateTimeInput(attrs = {'class':'form-control','placeholder':'found in eg 2004'}), 
            'meter_number' : forms.TextInput(attrs = {'class':'form-control','placeholder':'meter_number'}),
            'province' : forms.TextInput(attrs = {'class':'form-control','placeholder':'province'}),
            'location' : forms.TextInput(attrs = {'class':'form-control','placeholder':'location'}), 
            'companyfield':forms.TimeInput(attrs ={'hidden':'True','value':'True'}),  

        }

class BillingForm(forms.ModelForm): 
    class Meta:
        model=Billing
        fields=['purchasedkilo','amountpaid']
        widgets = {
            'amountpaid' : forms.TextInput(attrs = {'class':'form-control','placeholder':'$ Amount to pay'}),
            'purchasedkilo' : forms.TextInput(attrs = {'class':'form-control','placeholder':'Enter amount of Kiloliters'}),
        }

class ExternalPaymentForm(forms.Form):
    card_number = forms.CharField(max_length=16, label='Card Number')
    meter_number = forms.CharField(max_length=50, label='Meter Number')
    payer_full_name = forms.CharField(max_length=100, label='Payer Full Name')
    payer_country = forms.CharField(max_length=50, label='Payer Country')
    amount = forms.FloatField(label='Amount (in liters)')

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field in self.fields.values():
            field.widget.attrs.update({'class': 'form-control'})      

class WaterTransferForm(forms.Form):
    meter_number = forms.CharField(max_length=50, label='Meter Number', widget=forms.TextInput(attrs={'class': 'form-control'}))




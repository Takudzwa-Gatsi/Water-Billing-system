$(document).ready(function() {
    $('#dataTable2').DataTable();
  });
  
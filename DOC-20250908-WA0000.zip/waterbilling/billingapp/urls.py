from django.urls import path
from .import views

urlpatterns = [
     path('',views.home,name='home'),
     path('login/',views.userlogin,name='login'),
     path('logout/',views.userlogout,name='logout'),
     path('register/',views.register,name='register'),
     path('billsadmin/',views.billsadmin,name='billsadmin'),
     path('waterbills/',views.waterbills,name='waterbills'),
     path('paybill/',views.paybill,name='paybill'),
     path('bill/<int:id>',views.bill,name='bill'),
     path('usage/',views.waterusage,name='usage'),
     path('compreg/',views.compreg,name='compreg'),
     path('external_payment/',views.external_payment, name='external_payment'),
     path('transfer_water/', views.transfer_water, name='transfer_water'),
     path('process_transfer/',views.process_transfer, name='process_transfer'),
     path('virtual_meter/', views.virtual_meter, name='virtual_meter'),
     path('usage_stats/', views.usage_stats, name='usage_stats'),
     path('diaspora/', views.diaspora, name='diaspora'),
]
from django.db import models
from django.contrib.auth.models import AbstractUser
from django.utils import timezone

class User(AbstractUser):
    firstname=models.CharField(max_length=500,blank=True)
    lastname=models.CharField(max_length=500,blank=True)
    dob=models.DateField(blank=True,null=True)
    phone=models.IntegerField(blank=True,null=True)
    address=models.CharField(max_length=200,blank=True,null=True)
    province=models.CharField(max_length=200,blank=True,null=True)
    location=models.CharField(max_length=200,blank=True,null=True)
    meter_number=models.CharField(max_length=50)
    companyfield=models.BooleanField(default=False)
    profile_image=models.ImageField(upload_to='profile',default='profile/myprof.png')

class Billing(models.Model):
    client=models.ForeignKey(User,on_delete=models.CASCADE,related_name='clt')
    availablekilo=models.FloatField(default=0.0)
    date=models.DateField(blank=True,null=True,default=timezone.now)
    amountpaid=models.FloatField(blank=True,null=True)
    receiptno=models.CharField(max_length=200)
    purchasedkilo=models.FloatField(blank=True,null=True)
    newkilos=models.FloatField(blank=True,null=True)

class Meter(models.Model):
    owner=models.ForeignKey(User,on_delete=models.CASCADE,related_name='own')
    meter_number=models.CharField(max_length=50)
    availablekilo=models.FloatField()
    date=models.DateField(blank=True,null=True,default=timezone.now)


class Rates(models.Model):
     amountofkilos=models.IntegerField()
     price=models.FloatField()


class BankAccount(models.Model):
      balance=models.FloatField()


class Transfer(models.Model):
    sender = models.ForeignKey(User, on_delete=models.CASCADE, related_name='transfers_sent')
    receiver = models.ForeignKey(User, on_delete=models.CASCADE, related_name='transfers_received')
    kiloliters_shared = models.FloatField()
    date = models.DateTimeField(default=timezone.now)

    def __str__(self):
        return f"{self.sender.username} -> {self.receiver.username}: {self.kiloliters_shared} kL on {self.date}"
    
class Transaction(models.Model):
    payer = models.ForeignKey(User, on_delete=models.CASCADE, related_name='transactions_made')
    receiver = models.ForeignKey(User, on_delete=models.CASCADE, related_name='transactions_received')
    amount_paid = models.FloatField()
    kiloliters_transferred = models.FloatField()
    date = models.DateTimeField(default=timezone.now)

class WaterUsage(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='water_usage')
    date = models.DateTimeField(default=timezone.now)
    usage_kilos = models.FloatField()
    cost = models.FloatField()

    def __str__(self):
        return f"{self.user.username} used {self.usage_kilos} kL on {self.date} for ${self.cost:.2f}"


   
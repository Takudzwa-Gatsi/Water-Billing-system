from django.shortcuts import render,redirect, get_object_or_404
from django.contrib.auth import login,logout,authenticate
from django.views.decorators.csrf import csrf_exempt
from django.contrib import messages
from django.db.models import Q
from .forms import*
from .models import*
from django.http import HttpResponse
import os
import random
from django.db import transaction
from django.utils import timezone

def home(request):
    return render(request,'home.html')


def userlogout(request):
    logout(request)
    return redirect('login')

def userlogin(request):
    if request.user.is_authenticated:
            return redirect('waterbills')
    else:
       if request.method=="POST":
        username=request.POST.get('username')
        password=request.POST.get('password')
        user=authenticate(request,username=username,password=password)
        if user is not None:
            login(request,user)
            if user.companyfield==True:
                return  redirect('comp')
            elif user.is_superuser==True:
                 return redirect('billsadmin')
            return redirect('waterbills')
        else:
             messages.error(request, "Invalid username or password. Please try again.")
       
    return render(request,'login.html')


def register(request):
    form=UserForm()
    if request.method=='POST':
        form=UserForm(request.POST)
        if form.is_valid():
            form.save()
            #Meter.objects.create(owner=request.POST['username'], meter_number=request.POST['meter_number'],availablekilo=0)
            return redirect('home')
    return render(request,'register.html',{'form':form})

def compreg(request):
    form=CompForm()
    if request.method=='POST':
        form=CompForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('home')
    return render(request,'compreg.html',{'form':form})


def billsadmin(request):
    rescount=User.objects.exclude(Q(is_superuser=True)).count()
    staffcount=User.objects.exclude(Q(is_superuser=False)).count()
    comps=User.objects.exclude(Q(is_superuser=True) | Q(companyfield=False)).count()
    clients=User.objects.exclude(Q(is_superuser=True) | Q(companyfield=True))
    return render(request,'billsadmin.html',{'rescount':rescount,'comps':comps,'clients':clients,'staffcount':staffcount})


def waterbills(request):
    rate=Rates.objects.get(price=5.0)

    # Check for the existence of the meter
    meter, created = Meter.objects.get_or_create(
        owner=request.user,
        meter_number=request.user.meter_number,
        defaults={'availablekilo': 0}
    )
    
    if created:
        print("Meter created successfully.")
    else:
        print("Meter already exists.")
    
    meterx = get_object_or_404(Meter, owner=request.user)
    bills=Billing.objects.filter(client=request.user)
    
    return render(request,'waterbills.html',{'rate':rate,'bills':bills,'meterx':meterx})


def paybill(request):
    form=BillingForm()
    rate=Rates.objects.get(price=5.0)
    meter = get_object_or_404(Meter,owner=request.user)
    
    if request.method=='POST':
        purch=request.POST.get('purchasedkilo')
        amount=request.POST.get('amountpaid')
        rcpt=random.randint(1000000000,10000000000)
        newk=purch

        Billing.objects.create(client=request.user,amountpaid=amount,receiptno=rcpt,purchasedkilo=purch,newkilos=newk)
        amount=float(amount)
        meter.availablekilo+= amount
        meter.save()

        return redirect('waterbills')
    return render(request,'paybill.html',{'form':form,'rate':rate})


def bill(request,id):
    bill=Billing.objects.get(id=id)
    return render(request,'bill.html',{'bill':bill})


def waterusage(request):
    return render(request,'usage.html')

'''def external_payment(request):
    if request.method == 'POST':
        form = ExternalPaymentForm(request.POST)
        if form.is_valid():
            card_number = form.cleaned_data['card_number']
            meter_number = form.cleaned_data['meter_number']
            payer_full_name = form.cleaned_data['payer_full_name']
            payer_country = form.cleaned_data['payer_country']
            amount = form.cleaned_data['amount']

            # Fetch the meter details
            meter = get_object_or_404(Meter, meter_number=meter_number)
            receiver = meter.owner

            # Update the available kilo for the receiver's meter
            meter.availablekilo += amount
            meter.save()

            # Create a new Billing entry for the transfer
            Billing.objects.create(client=receiver, purchasedkilo=amount, amountpaid=amount,
                                   receiptno=random.randint(1000000000, 10000000000))

            # Record the transfer in the Transfer model
            #Transfer.objects.create(sender=None, receiver=receiver, kiloliters_shared=amount)

            # Record the transaction
            #Transaction.objects.create(payer=request.user, receiver=receiver, amount_paid=amount, kiloliters_transferred=amount)

            messages.success(request, f"Successfully processed payment of {amount} liters for {receiver.firstname} {receiver.lastname}.")
            return  redirect('diaspora')'''
def external_payment(request):
    if request.method == 'POST':
        form = ExternalPaymentForm(request.POST)
        if form.is_valid():
            card_number = form.cleaned_data['card_number']
            meter_number = form.cleaned_data['meter_number']
            payer_full_name = form.cleaned_data['payer_full_name']
            payer_country = form.cleaned_data['payer_country']
            amount = form.cleaned_data['amount']

            # Attempt to fetch the meter details
            try:
                meter = Meter.objects.get(meter_number=meter_number)
                receiver = meter.owner

                # Update the available kilo for the receiver's meter
                meter.availablekilo += amount
                meter.save()

                # Create a new Billing entry for the transfer
                Billing.objects.create(
                    client=receiver,
                    purchasedkilo=amount,
                    amountpaid=amount,
                    receiptno=random.randint(1000000000, 10000000000)
                )

                # Record the transfer in the Transfer model (if applicable)
                # Transfer.objects.create(sender=None, receiver=receiver, kiloliters_shared=amount)

                # Record the transaction (if applicable)
                # Transaction.objects.create(payer=request.user, receiver=receiver, amount_paid=amount, kiloliters_transferred=amount)

                messages.success(request, f"Successfully processed payment of {amount} liters for {receiver.firstname} {receiver.lastname}.")
                return redirect('diaspora')

            except Meter.DoesNotExist:
                form.add_error('meter_number', 'Meter not found. Please check the meter number and try again.')

    else:
        form = ExternalPaymentForm()

    return render(request, 'external_payment.html', {'form': form})


'''def transfer_water(request):
    if request.method == 'POST':
        form = WaterTransferForm(request.POST)
        if form.is_valid():
            meter_number = form.cleaned_data['meter_number']
            # Fetch the meter details
            meter = get_object_or_404(Meter, meter_number=meter_number)
            owner = meter.owner

            # Show confirmation message
            messages.info(request, f"You are about to transfer water to {owner.firstname} {owner.lastname}.")
            return render(request, 'confirm_transfer.html', {'owner': owner, 'meter': meter})

    else:
        form = WaterTransferForm()

    return render(request, 'transfer_water.html', {'form': form})'''


def transfer_water(request):
    if request.method == 'POST':
        form = WaterTransferForm(request.POST)
        if form.is_valid():
            meter_number = form.cleaned_data['meter_number']
            # Fetch the meter details
            try:
                meter = Meter.objects.get(meter_number=meter_number)
                owner = meter.owner

                # Show confirmation message
                return render(request, 'confirm_transfer.html', {'owner': owner, 'meter': meter})
            except Meter.DoesNotExist:
                # Add an error to the form if the meter does not exist
                form.add_error('meter_number', "The meter number you entered does not exist.")

    else:
        form = WaterTransferForm()

    return render(request, 'transfer_water.html', {'form': form})



def process_transfer(request):
    if request.method == 'POST':
        meter_number = request.POST.get('meter_number')
        amount = float(request.POST.get('amount'))

        meter = get_object_or_404(Meter, meter_number=meter_number)
        meter_sender = get_object_or_404(Meter, owner=request.user)
        sender = request.user
        receiver = meter.owner

        # Update the available kilo for the receiver's meter
        meter.availablekilo += amount
        meter.save()
        meter_sender.availablekilo-=amount
        meter_sender.save()

        # Create a new Billing entry for the transfer
        Billing.objects.create(client=receiver, purchasedkilo=amount, amountpaid=amount,
                               receiptno=random.randint(1000000000, 10000000000))

        # Record the transfer in the Transfer model
        Transfer.objects.create(sender=sender, receiver=receiver, kiloliters_shared=amount)

        # Record the transaction
        Transaction.objects.create(payer=sender, receiver=receiver, amount_paid=amount, kiloliters_transferred=amount)

        messages.success(request, f"Successfully transferred {amount} liters of water to {receiver.firstname} {receiver.lastname}.")
        return redirect('waterbills')


def virtual_meter(request):
    if request.user.is_authenticated:
        # Fetch the user's meter
        meter = get_object_or_404(Meter, owner=request.user)
        usedkilos=random.randint(2000,5000)
        multiplier=usedkilos/1000

        # Check if there are enough available kilos
        if meter.availablekilo >= 2000:
            # Deduct 2 kilos

            meter.availablekilo -= usedkilos
            meter.save()

            rate = get_object_or_404(Rates, amountofkilos=1)  # Adjust as needed

            total_cost = rate.price*multiplier  # Cost for the 2 kiloliters

            # Update Water Usage model
            WaterUsage.objects.create(
                user=request.user,
                usage_kilos=usedkilos,
                cost=total_cost,
                date=timezone.now()
            )

            messages.success(request, f"{usedkilos} kiloliters have been used.")
        else:
            messages.error(request, "You are running out of water.")

        # Render the virtual meter page
        return render(request, 'virtual_meter.html', {'meter': meter})
    else:
        return redirect('waterbills')


def usage_stats(request):
    # Get all water usages for the logged-in user
    water_usages = WaterUsage.objects.filter(user=request.user)
    
    # Get the current date and time
    now = timezone.now()
    current_month = now.month
    previous_month = (current_month - 1) or 12  # Handle December to January transition
    
    # Calculate current month's usage
    current_usage = sum(usage.usage_kilos for usage in water_usages.filter(date__month=current_month))
    
    # Calculate previous month's usage
    previous_usage = sum(usage.usage_kilos for usage in water_usages.filter(date__month=previous_month))
    
    # Prepare previous month comparison
    if previous_usage > 0:
        previous_comparison = f"{((current_usage - previous_usage) / previous_usage) * 100:.1f}% decrease" if current_usage < previous_usage else f"{((current_usage - previous_usage) / previous_usage) * 100:.1f}% increase"
    else:
        previous_comparison = "N/A"

    # Prepare data for chart
    usage_labels = [usage.date.strftime("%d/%m") for usage in water_usages]
    usage_data = [usage.usage_kilos for usage in water_usages]

    context = {
        'current_usage': current_usage,
        'previous_comparison': previous_comparison,
        'water_usages': water_usages,
        'usage_labels': usage_labels,
        'usage_data': usage_data,
    }
    
    return render(request, 'usagex.html', context)

def diaspora(request):
    return render(request,'diaspora.html')